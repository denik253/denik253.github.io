import React, { useState } from "react";
import Chatbot from "./Chatbot";
import "./chatBotButton.css"

const СhatBotButton = () =>{
    const [isChatbotVisible, setIsChatbotVisible] = useState(false);

    const toggleVisibility = () => {
      setIsChatbotVisible((prevState) => !prevState);
};

return (
    <div className="chatbot-wrapper">
      <button onClick={toggleVisibility} className="button">
        ?
      </button>
      {isChatbotVisible && <Chatbot />}
    </div>
  );
}

export default СhatBotButton;